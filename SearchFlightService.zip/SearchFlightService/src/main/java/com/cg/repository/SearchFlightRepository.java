package com.cg.repository;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.cg.models.Flight;

@Repository
public class SearchFlightRepository {

//	@Query(value="SELECT * FROM flight f where flight_from =?1 AND flight_to =?2 AND date =?3",nativeQuery=true)
//	public List<Flight> searchFlight(String flightFrom,String flightTo,String date);

	public static final String HASH_KEY = "Flight";
	@Autowired
	private RedisTemplate template;

	public List<Flight> searchFlight(String flightFrom,String flightTo,String date){
		List<Flight> flightRes=template.opsForHash().values(HASH_KEY);
		System.out.println("FlightRes:"+flightRes);
		for(Flight f : flightRes) {
			System.out.println("id:"+f.getId());
			System.out.println("flightFrom:"+f.getFlightFrom());
		}
		List<Flight> filteredList = flightRes.stream()
										  .filter(fli->fli.getFlightFrom().equals(flightFrom) &&
												fli.getFlightTo().equals(flightTo) && fli.getDate().equals(date))
										  .collect(Collectors.toList());
		 System.out.println("fliterlist:"+filteredList);
		 return filteredList;
    }
}
