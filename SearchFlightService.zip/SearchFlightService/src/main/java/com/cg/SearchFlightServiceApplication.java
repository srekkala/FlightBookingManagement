package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchFlightServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchFlightServiceApplication.class, args);
	}

}
